package net.minecraft.client.gui;

public interface GuiYesNoCallback
{
    void confirmClicked(boolean var1, int var2);
}
