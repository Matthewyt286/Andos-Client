package de.Hero.clickgui.util;

import java.awt.Color;

import Andos.Andos;
import Andos.Module.Module;

/**
 *  Made by HeroCode
 *  it's free to use
 *  but you have to credit me
 *
 *  @author HeroCode
 */
public class ColorUtil {
	
	public static Color getClickGUIColor(){
		return new Color((int)Andos.instance.settingsManager.getSettingByName("GuiRed").getValDouble(), (int)Andos.instance.settingsManager.getSettingByName("GuiGreen").getValDouble(), (int)Andos.instance.settingsManager.getSettingByName("GuiBlue").getValDouble());
	}
}
