package Andos.ui;

import java.util.Collections;
import java.util.Comparator;

import Andos.Andos;
import Andos.Module.Module;
import Andos.Module.combat.KillAura2;
import Andos.Module.render.HudMod;
import Andos.utils.AuraUtil;
import Andos.utils.ColorUtils;
import Andos.utils.RoundUtils;
import de.Hero.clickgui.util.FontUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public class HUD {
	
	public static class ModuleComparator implements Comparator<Module> {

		public int compare(Module o1, Module o2) {
			if (Minecraft.getMinecraft().fontRendererObj
					.getStringWidth(o1.name) > Minecraft.getMinecraft().fontRendererObj.getStringWidth(o2.name)) {
				return -1;
			}
			if (Minecraft.getMinecraft().fontRendererObj
					.getStringWidth(o1.name) < Minecraft.getMinecraft().fontRendererObj.getStringWidth(o2.name)) {
				return 1;
			}

			return 0;
		}

	}
	
	public static void render() {
		
		ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft(), Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
		FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
		
		Collections.sort(Andos.moduleManager.getModules(), new ModuleComparator());
		
		if(HudMod.HUD) {
			
			GlStateManager.pushMatrix();
			GlStateManager.scale(1.3, 1.3, 1.3);
			
			Gui.drawRect(4, 3, 132, 13, 0x90000000);
			Gui.drawRect(4, 3, 132, 2, ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
			Gui.drawRect(68, 3, 69, 13, -1);
			Gui.drawRect(111, 3, 110, 13, -1);
			
			
			FontUtil.drawStringWithShadow("A", 6, 4,
					ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
			
			FontUtil.drawStringWithShadow("ndos", 12, 4,
					-1);
			
			FontUtil.drawStringWithShadow("C", 38, 4,
					ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
			
			FontUtil.drawStringWithShadow("lient", 44, 4,
					-1);
			
			FontUtil.drawStringWithShadow("FPS:" + Minecraft.getMinecraft().func_175610_ah(), 71, 4,
					-1);
			
			FontUtil.drawStringWithShadow("v" + Andos.ver, 112, 4,
							-1);
			
			GlStateManager.popMatrix();
			
			if(KillAura2.target != null && AuraUtil.shouldAttack(KillAura2.target) && KillAura2.KAT) {
				Gui.drawRect(5, 20, 172, 65, 0x90000000);
				GlStateManager.pushMatrix();
				GlStateManager.scale(1.3, 1.3, 1.3);
				FontUtil.drawString("Name: " + KillAura2.target.getName(), 7, 18, -1);
				FontUtil.drawString("Health: " + (int) (KillAura2.target.getHealth()) + ".0 / " + (int) (KillAura2.target.getMaxHealth()) + ".0", 7, 28, -1);
				
				if(KillAura2.target.getHealth() / 4 > 1) {
					Gui.drawRect(4, 38, 30, 42, ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
				}
				if(KillAura2.target.getHealth() / 4 > 2) {
					Gui.drawRect(30, 38, 60, 42, ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
				}
				if(KillAura2.target.getHealth() / 4 > 3) {
					Gui.drawRect(60, 38, 90, 42, ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
				}
				if(KillAura2.target.getHealth() / 4 > 4) {
					Gui.drawRect(90, 38, 120, 42, ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
				}
				GlStateManager.popMatrix();
				
			}
			
//			FontUtil.drawStringWithShadow("FPS:" + Minecraft.getMinecraft().func_175610_ah(),
//					126, 5, -1);

			int count = 0;

			for (Module m : Andos.instance.moduleManager.getModules()) {
				if (!m.isToggled())
					continue;

				double offset = count * (fr.FONT_HEIGHT + 6);

				
				
//				Gui.drawRect(sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 8, offset,
//						sr.getScaledWidth(), 6 + fr.FONT_HEIGHT + offset, 0x90000000);
				

				
				Gui.drawRect(sr.getScaledWidth() - 3, offset, sr.getScaledWidth(), 6 + fr.FONT_HEIGHT + offset, ColorUtils.rainbowEffect(count * 200000000L, 1.0F).getRGB());
				
				FontUtil.drawStringWithShadow(m.getName(), sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 5, 4 + offset, ColorUtils.rainbowEffect(count * 200000000L, 1.0F).getRGB());
				
				
				count++;
			}
			
		}
	}

}
