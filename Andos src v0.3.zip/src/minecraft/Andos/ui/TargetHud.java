//package Andos.ui;
//
//import Andos.Module.combat.KillAura2;
//import Andos.Module.render.HudMod;
//import de.Hero.clickgui.util.FontUtil;
//import net.minecraft.client.Minecraft;
//import net.minecraft.client.gui.Gui;
//
//public class TargetHud {
//	
//	public int x = 150;
//	public int y = 150;
//	
//	public void draw() {
//		if(HudMod.HUD) {
//			renderTargetHud(KillAura2.target.getName(), KillAura2.target.getHealth(), KillAura2.target.getMaxHealth());
//		}
//	}
//	
//	
//	public void renderTargetHud(String name, double health, double mHealth) {
//		FontUtil.drawStringWithShadow(name, x + 2, y + 2, -1);
//	}
//
//}
