package Andos.Module.render;

import Andos.Module.Category;
import Andos.Module.Module;

public class NoScoreboard extends Module{
	
	public static boolean nsb = false;
	
	public NoScoreboard() {
		super("NoScoreboard", 0, Category.RENDER);
	}
	
	public void onEnable() {
		nsb = true;
	}
	
	public void onDisable() {
		nsb = false;
	}

}
