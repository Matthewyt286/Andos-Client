package Andos.Module.render;

import org.lwjgl.input.Keyboard;

import Andos.Module.Module;
import Andos.Module.Category;

public class FullBright extends Module{

	public FullBright() {
		super("FullBright", Keyboard.KEY_P, Category.RENDER);
	}
	
	public void onEnable() {
		mc.gameSettings.gammaSetting = 100;
	}
	
	public void onDisable() {

		mc.gameSettings.gammaSetting = 1;
	}
}
