package Andos.Module.render;

import Andos.Module.Category;
import Andos.Module.Module;

public class ShaderESP extends Module{
	
	public static boolean shaderespToggle = false;
	
	public ShaderESP() {
		super("ShaderESP", 0, Category.RENDER);
	}
	
	public void onEnable() {
		shaderespToggle = true;
	}
	
	public void onDisable() {
		shaderespToggle = false;
	}

}
