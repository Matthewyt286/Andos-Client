package Andos.Module.render;

import Andos.Module.Category;
import Andos.Module.Module;
import Andos.utils.esp.MobESPUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class PlayerESP extends Module{

	public PlayerESP() {
		super("PlayerESP", 0, Category.RENDER);
	}
	
	@Override
	public void onRender() {
		if(this.isToggled()) {
			for(Object p: mc.theWorld.loadedEntityList) {
				if(p instanceof EntityPlayer && (!(p instanceof EntityPlayerSP))) {
					MobESPUtils.entityESPBox((Entity)p, 0xffff9000);
				}
			}
		}
	}

}
