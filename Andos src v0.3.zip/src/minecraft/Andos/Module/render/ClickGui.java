package Andos.Module.render;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;

public class ClickGui extends Module{

        public ClickGui() {
        super("ClickGui", Keyboard.KEY_RSHIFT, Category.RENDER);
    }

    @Override
    public void setup() {
        ArrayList<String> options = new ArrayList<String>();
        options.add("New");
        options.add("JellyLike");
        Andos.instance.settingsManager.rSetting(new Setting("Design", this, "New", options));
        Andos.instance.settingsManager.rSetting(new Setting("Sound", this, false));
        Andos.instance.settingsManager.rSetting(new Setting("GuiRed", this, 255, 0, 255, true));
        Andos.instance.settingsManager.rSetting(new Setting("GuiGreen", this, 26, 0, 255, true));
        Andos.instance.settingsManager.rSetting(new Setting("GuiBlue", this, 42, 0, 255, true));
    }

    @Override
    public void onEnable() {
        super.onEnable();

        mc.displayGuiScreen(Andos.instance.clickGUI);
        toggle();
    }
}