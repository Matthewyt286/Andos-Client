package Andos.Module.render;

import Andos.Module.Category;
import Andos.Module.Module;

public class HudMod extends Module{

	public static boolean HUD = true;
	
	public HudMod() {
		super("HUD", 0, Category.RENDER);
		toggled = true;
	}
	
	public void onEnable() {
		HUD = true;
	}
	
	public void onDisable() {
		HUD = false;
	}
	
	

}
