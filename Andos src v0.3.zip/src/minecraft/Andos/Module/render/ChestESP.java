package Andos.Module.render;

import Andos.Module.Category;
import Andos.Module.Module;
import Andos.utils.esp.ChestESPUtils;
import net.minecraft.tileentity.TileEntityChest;

public class ChestESP extends Module{

	public ChestESP() {
		super("ChestESP", 0, Category.RENDER);
	}
	
	public void onRender() {
		if(this.isToggled()) {
			for(Object o: mc.theWorld.loadedTileEntityList) {
				if(o instanceof TileEntityChest) {
					ChestESPUtils.blockESPBox(((TileEntityChest)o).getPos());
				}
			}
		}
	}

}
