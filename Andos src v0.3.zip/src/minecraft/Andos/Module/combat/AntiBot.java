package Andos.Module.combat;

import java.util.ArrayList;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import de.Hero.settings.Setting;
import net.minecraft.entity.EntityLivingBase;

public class AntiBot extends Module{
	
	public static boolean AT = false;
	
	public static boolean A1 = false;

	public AntiBot() {
		super("AntiBot", 0, Category.COMBAT);
	}
	
	public void setup() {
        Andos.instance.settingsManager.rSetting(new Setting("Invis", this, false));
	}
	
	public void onEnable() {
		AT = true;
	}
	
	public void onDisable() {
		AT = false;
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			if(Andos.instance.settingsManager.getSettingByName("Invis").getValBoolean()) {
				A1 = true;
			}else {
				A1 = false;
			}
		}
	}

}
