package Andos.Module.combat;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import Andos.utils.AuraUtil;
import Andos.utils.RotationUtil;
import Andos.utils.TimeUtil;
import de.Hero.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
//import me.Andos.blocking;
//import me.Andos.Andos;
//import me.Andos.utils.AuraUtil;
//import me.Andos.utils.RotationUtil;
//import me.Andos.utils.TimeUtil;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemSword;
import net.minecraft.util.MathHelper;

public class KillAura2 extends Module {
	
	public static boolean blocking = false;
	
	public static boolean KAT = false;

	public KillAura2() {
		super("KillAura", Keyboard.KEY_R, Category.COMBAT);
	}
	
	@Override
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("OFF");
        options.add("Fake");
        options.add("Real");
        
        Andos.instance.settingsManager.rSetting(new Setting("AutoBlock", this, "OFF", options));
        
		Andos.instance.settingsManager.rSetting(new Setting("AuraRange", this, 4, 3, 6, false));
		Andos.instance.settingsManager.rSetting(new Setting("AuraAPS", this, 13, 1, 20, true));
		Andos.instance.settingsManager.rSetting(new Setting("Show Attacking", this, false));
	}
	
	public static float yaw, pitch;
	public static EntityLivingBase target;
	private final TimeUtil timeUtil = new TimeUtil();

	@Override
	@SuppressWarnings("unused")
	public void onUpdate() {
		onPreUpdate();
		target = AuraUtil.getTarget(Andos.instance.settingsManager.getSettingByName("AuraRange").getValDouble());
		
		if(target == null || !this.isToggled())
			return;
		
		float[] rotations = getRotationsNeeded(target);
		yaw = rotations[0];
		pitch = rotations[1];
		
		float[] rotation = getRotationsNeeded(target);
		mc.thePlayer.rotationYawHead = rotation[0];
		mc.thePlayer.rotationPitchHead = rotation[1];
		
		if(timeUtil.hasTimePassed((long) (1000 / Andos.instance.settingsManager.getSettingByName("AuraAPS").getValDouble()))) {
			AuraUtil.attack(target);
//			sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, yaw, pitch, mc.thePlayer.onGround));
			if(Andos.instance.settingsManager.getSettingByName("Show Attacking").getValBoolean()) {
				Andos.instance.moduleManager.addChatMessage("ATTACKING: " + target.getName() + ", HEALTH: " + target.getHealth() + "/" + target.getMaxHealth());
			}
			timeUtil.reset();
		}
	}
	
	private void onPreUpdate() {
		if(target == null || !this.isToggled())
			return;

		float[] rotation = getRotationsNeeded(target);
		mc.thePlayer.rotationYawHead = rotation[0];
		mc.thePlayer.rotationPitchHead = rotation[1];
		
//		mc.thePlayer.rotationYaw = rotation[0];
//		mc.thePlayer.rotationPitch = rotation[1];
	}

	@Override
	public void onEnable() {
		if(Andos.instance.settingsManager.getSettingByName("AutoBlock").getValString().equalsIgnoreCase("Fake"))
			blocking = true;
		if(Andos.instance.settingsManager.getSettingByName("AutoBlock").getValString().equalsIgnoreCase("Real"))
			if(mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
				mc.gameSettings.keyBindUseItem.pressed = true;
			}
		super.onEnable();
		KAT = true;
		target = null;
	}

	@Override
	public void onDisable() {
		mc.gameSettings.keyBindUseItem.pressed = false;
		blocking = false;
		KAT = false;
		super.onDisable();
	}
	
	public static float[] getRotationsNeeded(final Entity entity) {
        if (entity == null) {
            return null;
        }
        Minecraft mc = Minecraft.getMinecraft();
        final double xSize = entity.posX - mc.thePlayer.posX;
        final double ySize = entity.posY + entity.getEyeHeight() / 2 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight() - 0.2);
        final double zSize = entity.posZ - mc.thePlayer.posZ;
        final double theta = MathHelper.sqrt_double(xSize * xSize + zSize * zSize);
        final float yaw = (float) (Math.atan2(zSize, xSize) * 180 / Math.PI) - 90;
        final float pitch = (float) (-(Math.atan2(ySize, theta) * 180 / Math.PI));
        return new float[]{(mc.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - mc.thePlayer.rotationYaw)) % 360, (mc.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - mc.thePlayer.rotationPitch)) % 360.0f};
    }

}
