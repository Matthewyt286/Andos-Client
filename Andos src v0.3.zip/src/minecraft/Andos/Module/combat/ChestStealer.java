package Andos.Module.combat;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import Andos.Andos;
import Andos.Module.Module;
import Andos.Module.Category;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.S30PacketWindowItems;

public class ChestStealer extends Module{
	
	public static S30PacketWindowItems packet;
	int delay;

	public ChestStealer() {
		super("ChestStealer", Keyboard.KEY_C, Category.COMBAT);
	}

	@Override
	public void setup() {
		Andos.instance.settingsManager.rSetting(new Setting("Steal Delay", this, 0, 0.1, 15, true));

	}
	
	@Override
	public void onEnable() {
	}
	
	@Override
	public void onDisable() {
	}

	@Override
	public void onUpdate() {
		if (!this.isToggled())
			return;
		this.delay += Andos.instance.settingsManager.getSettingByName("Steal Delay").getValDouble();
		if ((mc.currentScreen instanceof GuiChest)) {
			GuiChest chest = (GuiChest) mc.currentScreen;
			if (isChestEmpty(chest)) {
				mc.thePlayer.closeScreen();
				packet = null;
			}
			for (int index = 0; index < chest.lowerChestInventory.getSizeInventory(); index++) {
				ItemStack stack = chest.lowerChestInventory.getStackInSlot(index);
				if ((stack != null) && (this.delay > 2) && (!stack.hasDisplayName())) {
					mc.playerController.windowClick(chest.inventorySlots.windowId, index, 0, 1, mc.thePlayer);
					this.delay = 0;
				}
			}
		}
	}

	private boolean isChestEmpty(GuiChest chest) {
		for (int index = 0; index <= chest.lowerChestInventory.getSizeInventory(); index++) {
			ItemStack stack = chest.lowerChestInventory.getStackInSlot(index);
			if (stack != null) {
				return false;
			}
		}
		return true;
	}
}