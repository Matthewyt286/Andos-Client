package Andos.Module.combat;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import Andos.Andos;
import Andos.Module.Module;
import Andos.Module.Category;

public class Velocity extends Module {

	public void setup() {
		Andos.instance.settingsManager.rSetting(new Setting("Horizontal", this, 90, 0, 100, true));
		Andos.instance.settingsManager.rSetting(new Setting("Vertical", this, 100, 0, 100, true));
	}

	public Velocity() {
		super("Velocity", Keyboard.KEY_Z, Category.COMBAT);
	}

	public void onUpdate() {
		float horizontal = (float) Andos.instance.settingsManager.getSettingByName("Horizontal").getValDouble();
		float vertical = (float) Andos.instance.settingsManager.getSettingByName("Vertical").getValDouble();

		if (!this.isToggled())
			return;

			if (mc.thePlayer.hurtTime == mc.thePlayer.maxHurtTime && mc.thePlayer.maxHurtTime > 0) {
				mc.thePlayer.motionX *= (float) horizontal / 100;
				mc.thePlayer.motionY *= (float) vertical / 100;
				mc.thePlayer.motionZ *= (float) horizontal / 100;
			}
	}

}
