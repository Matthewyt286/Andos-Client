package Andos.Module.combat;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import de.Hero.settings.Setting;
import io.netty.util.internal.ThreadLocalRandom;
import net.minecraft.client.settings.KeyBinding;

public class AutoClicker extends Module {

	private long lastClick;
	private long hold;

	private double speed;
	private double holdLength;
	private double min;
	private double max;

	public void setup() {
		Andos.instance.settingsManager.rSetting(new Setting("MinCPS", this, 8, 1, 20, false));
		Andos.instance.settingsManager.rSetting(new Setting("MaxCPS", this, 12, 1, 20, false));
	}

	public AutoClicker() {
		super("AutoClicker", Keyboard.KEY_I, Category.COMBAT);
	}

	@Override
	public void onUpdate() {
		if (this.isToggled()) {
			if (Mouse.isButtonDown(0)) {
				if (System.currentTimeMillis() - lastClick > speed * 1000) {
					lastClick = System.currentTimeMillis();
					if (hold < lastClick) {
						hold = lastClick;
					}
					int key = mc.gameSettings.keyBindAttack.getKeyCode();
					KeyBinding.setKeyBindState(key, true);
					KeyBinding.onTick(key);
					this.updateVals();
				} else if (System.currentTimeMillis() - hold > holdLength * 1000) {
					KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
					this.updateVals();
				}
			}
		}
	}

	@Override
	public void onEnable() {
		super.onEnable();
		this.updateVals();
	}

	private void updateVals() {
		min = Andos.instance.settingsManager.getSettingByName("MinCPS").getValDouble();
		max = Andos.instance.settingsManager.getSettingByName("MaxCPS").getValDouble();

		if (min >= max) {
			max = min + 1;
		}
		speed = 1.0 / ThreadLocalRandom.current().nextDouble(min, max);
		holdLength = speed / ThreadLocalRandom.current().nextDouble(min, max);

	}

}
