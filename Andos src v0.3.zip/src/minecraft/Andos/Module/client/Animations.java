package Andos.Module.client;

import java.util.ArrayList;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import Andos.Module.combat.KillAura2;
import de.Hero.settings.Setting;

public class Animations extends Module{
	
	public static int aniMode = 0;
	
	public static double itemX = 0;
	public static double itemY = 0;
	public static double itemZ = 0;
	
	public Animations() {
		super("Animations", 0, Category.CLIENT);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("None");
        options.add("Vanilla");
        options.add("1.7");
        options.add("Tap1");
        options.add("Slide Remix");
        options.add("Slide Remix2");
        
        Andos.instance.settingsManager.rSetting(new Setting("Animation", this, "None", options));
        Andos.instance.settingsManager.rSetting(new Setting("Swing Animations", this, false));
        Andos.instance.settingsManager.rSetting(new Setting("NO ANI", this, false));

        Andos.instance.settingsManager.rSetting(new Setting("Always Block", this, false));
        
		Andos.instance.settingsManager.rSetting(new Setting("ItemX", this, itemX, 0, 10, false));
		Andos.instance.settingsManager.rSetting(new Setting("ItemY", this, itemY, 0, 10, false));
		Andos.instance.settingsManager.rSetting(new Setting("ItemZ", this, itemZ, 0, 10, false));
        
	}
	
	public void onEnable() {
		toggle();
	}
	
	public void onUpdate() {
		if(Andos.instance.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("None")) {
			aniMode = 0;
		}
		if(Andos.instance.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Vanilla")) {
			aniMode = 1;
		}
		if(Andos.instance.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Tap1")) {
			aniMode = 2;
		}
		if(Andos.instance.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Slide Remix")) {
			aniMode = 3;
		}
		if(Andos.instance.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Slide Remix2")) {
			aniMode = 4;
		}
		if(Andos.instance.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("1.7")) {
			aniMode = 5;
		}
		if(Andos.instance.settingsManager.getSettingByName("Always Block").getValBoolean()) {
			KillAura2.blocking = true;
		}else {
			if(KillAura2.KAT != true && KillAura2.target != null)
				KillAura2.blocking = false;
		}
		itemX = Andos.settingsManager.getSettingByName("ItemX").getValDouble();
		itemY = Andos.settingsManager.getSettingByName("ItemY").getValDouble();
		itemZ = Andos.settingsManager.getSettingByName("ItemZ").getValDouble();
	}
	
	

}
