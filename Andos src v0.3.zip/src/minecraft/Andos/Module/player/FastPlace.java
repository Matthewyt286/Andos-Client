package Andos.Module.player;

import Andos.Module.Module;

import org.lwjgl.input.Keyboard;

import Andos.Module.Category;

public class FastPlace extends Module{

	public FastPlace() {
		super("FastPlace", Keyboard.KEY_K, Category.PLAYER);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			mc.rightClickDelayTimer = 0;
		}
	}

}
