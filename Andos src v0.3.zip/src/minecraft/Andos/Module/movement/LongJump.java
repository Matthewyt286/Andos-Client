package Andos.Module.movement;

import Andos.Module.Module;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import Andos.Andos;
import Andos.Module.Category;

import Andos.utils.TimerUtils;
import de.Hero.settings.Setting;

public class LongJump extends Module {

	public TimerUtils timer = new TimerUtils();
	public double startY = 0;
	public boolean b1 = false;

	public LongJump() {
		super("LongJump", Keyboard.KEY_L, Category.MOVEMENT);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("OLDPika");
        options.add("Test");
        
        Andos.instance.settingsManager.rSetting(new Setting("LongJump Mode", this, "OLDPika", options));
	}

	@Override
	public void onDisable() {
		mc.timer.timerSpeed = 1f;
		b1 = false;
	}
	
	@Override
	public void onEnable() {
		if(Andos.instance.settingsManager.getSettingByName("LongJump Mode").getValString().equalsIgnoreCase("OLDPika")) {
			this.mc.thePlayer.setPosition(this.mc.thePlayer.lastTickPosX - 0.3, this.mc.thePlayer.lastTickPosY - 0.3, this.mc.thePlayer.lastTickPosZ - 0.3);
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX + 0.3, this.mc.thePlayer.posY + 0.3, this.mc.thePlayer.posZ + 0.3);
		}

		if(Andos.instance.settingsManager.getSettingByName("LongJump Mode").getValString().equalsIgnoreCase("Test")) {
			mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.3, mc.thePlayer.posZ);
			mc.thePlayer.jump();
			mc.thePlayer.jump();
			mc.thePlayer.jump();
			mc.thePlayer.jump();
			startY = player().posY;
			b1 = true;
		}
	}
	
	@Override
	public void onUpdate() {
		if (this.isToggled()) {
			if(Andos.instance.settingsManager.getSettingByName("LongJump Mode").getValString().equalsIgnoreCase("OLDPika")) {
				if (mc.gameSettings.keyBindJump.pressed) {
					mc.timer.timerSpeed = 0.5f;
					mc.thePlayer.setSprinting(toggled);
					mc.thePlayer.jump();
					mc.thePlayer.moveStrafing = 2f;
				}
			}
			if(Andos.instance.settingsManager.getSettingByName("LongJump Mode").getValString().equalsIgnoreCase("Test")) {
				if(!b1) return;
				mc.timer.timerSpeed = 0.8f;
				if (startY > player().posY)
					player().motionY = 0.5;
			}
		}
	}

}
