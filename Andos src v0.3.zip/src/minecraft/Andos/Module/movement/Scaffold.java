package Andos.Module.movement;

import org.lwjgl.input.Keyboard;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import Andos.utils.TimerUtils;
import de.Hero.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class Scaffold extends Module {

	public TimerUtils timer = new TimerUtils();
	
	public Scaffold() {
		super("Scaffold", Keyboard.KEY_J, Category.MOVEMENT);
	}

	public void setup() {
		Andos.instance.settingsManager.rSetting(new Setting("Eagle", this, false));
	}

	@Override
	public void onUpdate() {
		if (this.isToggled()) {
			mc.thePlayer.setSprinting(false);
			if(Andos.instance.settingsManager.getSettingByName("Eagle").getValBoolean()) {
				ItemStack i = this.mc.thePlayer.getCurrentEquippedItem();
				BlockPos bP = new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 1D, this.mc.thePlayer.posZ);
				if(i != null) {
					if(i.getItem() instanceof ItemBlock) {
						this.mc.gameSettings.keyBindSneak.pressed = false;
						if(this.mc.theWorld.getBlockState(bP).getBlock() == Blocks.air) {
							this.mc.gameSettings.keyBindSneak.pressed = true;
						}
					}
					
				}
			}
			Entity p = player();
			BlockPos bp = new BlockPos(p.posX, p.getEntityBoundingBox().minY, p.posZ);
			if (valid(bp.add(0, -2, 0))) {
				place(bp.add(0, -1, 0), EnumFacing.UP);
				if(mc.gameSettings.keyBindJump.pressed) {
					mc.thePlayer.jump();
					
				}
			}

			else if (valid(bp.add(-1, -1, 0)))
				place(bp.add(0, -1, 0), EnumFacing.EAST);

			else if (valid(bp.add(1, -1, 0)))
				place(bp.add(0, -1, -1), EnumFacing.WEST);

			else if (valid(bp.add(0, -1, -1)))
				place(bp.add(0, -1, 0), EnumFacing.SOUTH);

			else if (valid(bp.add(0, -1, 1)))
				place(bp.add(0, -1, 0), EnumFacing.NORTH);

			else if (valid(bp.add(1, -1, 1))) {
				if (valid(bp.add(0, -1, 1)))
					place(bp.add(0, -1, 1), EnumFacing.NORTH);
				place(bp.add(1, -1, 1), EnumFacing.EAST);

			} else if (valid(bp.add(-1, -1, 1))) {
				if (valid(bp.add(-1, -1, 0)))
					place(bp.add(0, -1, 1), EnumFacing.WEST);
				place(bp.add(-1, -1, 1), EnumFacing.SOUTH);

			} else if (valid(bp.add(-1, -1, -1))) {
				if (valid(bp.add(0, -1, -1)))
					place(bp.add(0, -1, 1), EnumFacing.SOUTH);
				place(bp.add(-1, -1, 1), EnumFacing.WEST);

			} else if (valid(bp.add(1, -1, -1))) {
				if (valid(bp.add(1, -1, 0)))
					place(bp.add(1, -1, 0), EnumFacing.EAST);
				place(bp.add(1, -1, -1), EnumFacing.NORTH);
			}

		}
	}

	void place(BlockPos p, EnumFacing f) {
		if (f == EnumFacing.UP)
			p = p.add(0, -1, 0);

		else if (f == EnumFacing.NORTH)
			p = p.add(0, 0, 1);

		else if (f == EnumFacing.EAST)
			p = p.add(-1, 0, 0);

		else if (f == EnumFacing.SOUTH)
			p = p.add(0, 0, -1);

		else if (f == EnumFacing.WEST)
			p = p.add(1, 0, 1);

		EntityPlayerSP _p = player();

		if (_p.getHeldItem() != null && _p.getHeldItem().getItem() instanceof ItemBlock) {
			
			
			
			

			double x = p.getX() + 0.25 - _p.posX;
			double z = p.getZ() + 0.25 - _p.posZ;
			double y = p.getY() + 0.25 - _p.posY;
			double distance = MathHelper.sqrt_double(x * x + z * z);
			float yaw = (float) (Math.atan2(z, x) * 180 / Math.PI - 90);
			float pitch = (float) -(Math.atan2(y, distance) * 180 / Math.PI);
			
			sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(_p.posX, _p.posY, _p.posZ, yaw, pitch, _p.onGround));
//			mc.thePlayer.rotationYaw = yaw;
//			mc.thePlayer.rotationPitch = pitch;
			playerController().func_178890_a(_p, world(), _p.getHeldItem(), p, f, new Vec3(0.5, 0.5, 0.5));
			_p.swingItem();

		}

	}

	boolean valid(BlockPos p) {
		Block b = world().getBlock(p);
		return !(b instanceof BlockLiquid) && b.getMaterial() != Material.air;
	}

	public void onDisable() {
		mc.timer.timerSpeed = 1f;
		mc.gameSettings.keyBindSneak.pressed = false;
	}
	
}
