package Andos.Module.movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import Andos.utils.TimerUtils;
import de.Hero.settings.Setting;

public class Speed extends Module {
	
	public TimerUtils timer = new TimerUtils();

	public Speed() {
		super("Speed", Keyboard.KEY_X, Category.MOVEMENT);
	}

	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
		options.add("Vanilla");
		options.add("BHop");

		Andos.instance.settingsManager.rSetting(new Setting("Speed Mode", this, "Vanilla", options));
	}

	public void onDisable() {
		//
	}

	public void onEnable() {
		//
	}

	@Override
	public void onUpdate() {
		if (this.isToggled()) {
			if (Andos.instance.settingsManager.getSettingByName("Speed Mode").getValString().equalsIgnoreCase("BHop")) {
				if (mc.gameSettings.keyBindForward.pressed || mc.gameSettings.keyBindBack.pressed
						|| mc.gameSettings.keyBindLeft.pressed || mc.gameSettings.keyBindRight.pressed) {
					if (mc.thePlayer.onGround) {
						mc.thePlayer.jump();
						mc.thePlayer.setSprinting(true);
						mc.thePlayer.moveStrafing = 2f;
						mc.thePlayer.motionX *= 1.15;
						mc.thePlayer.motionZ *= 1.15;
						}
				}

			}
		}
	}

}
