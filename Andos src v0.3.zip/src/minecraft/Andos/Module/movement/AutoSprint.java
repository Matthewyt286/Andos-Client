package Andos.Module.movement;

import Andos.Module.Category;
import Andos.Module.Module;
import de.Hero.settings.Setting;

import java.util.ArrayList;

import Andos.Andos;

public class AutoSprint extends Module{

	public AutoSprint() {
		super("AutoSprint", 0, Category.MOVEMENT);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("Vanilla");
        
        Andos.instance.settingsManager.rSetting(new Setting("Sprint Mode", this, "Vanilla", options));
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if(Andos.instance.settingsManager.getSettingByName("Sprint Mode").getValString().equalsIgnoreCase("Vanilla")) {
				mc.thePlayer.setSprinting(true);
			}
		}
	}
	
	@Override
	public void onDisable() {
		mc.thePlayer.setSprinting(false);
		super.onDisable();
	}

}
