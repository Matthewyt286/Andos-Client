package Andos.Module.movement;

import org.lwjgl.input.Keyboard;

import Andos.Module.Module;
import Andos.Module.Category;

public class Jetpack extends Module{

	public Jetpack() {
		super("JetPack", Keyboard.KEY_B, Category.MOVEMENT);
		
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if(mc.gameSettings.keyBindJump.pressed) {
				mc.thePlayer.jump();
			}
		}
	}

}
