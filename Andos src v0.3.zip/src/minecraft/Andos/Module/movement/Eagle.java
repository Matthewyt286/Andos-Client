package Andos.Module.movement;

import org.lwjgl.input.Keyboard;

import Andos.Module.Module;
import Andos.Module.Category;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;

public class Eagle extends Module{

	public Eagle() {
		super("Eagle", Keyboard.KEY_F, Category.MOVEMENT);
	}
	
	public void onDisable() {
		this.mc.gameSettings.keyBindSneak.pressed = false;
	}
	
	public void onUpdate() {
		if(!this.isToggled())
			return;
		
		if(this.isToggled()) {
			ItemStack i = this.mc.thePlayer.getCurrentEquippedItem();
			BlockPos bP = new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 1D, this.mc.thePlayer.posZ);
			if(i != null) {
				if(i.getItem() instanceof ItemBlock) {
					this.mc.gameSettings.keyBindSneak.pressed = false;
					if(this.mc.theWorld.getBlockState(bP).getBlock() == Blocks.air) {
						this.mc.gameSettings.keyBindSneak.pressed = true;
					}
				}
				
			}
		}
	}

}
