package Andos.Module.movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import Andos.utils.TimerUtils;
import Andos.utils.TimerUtils2;
import de.Hero.settings.Setting;
import net.minecraft.block.material.Material;

public class Flight extends Module{
	
	public TimerUtils timer = new TimerUtils();
	public static boolean damaged = false;
	public double startY = 0;
	
	public Flight() {
		super("Flight", Keyboard.KEY_G, Category.MOVEMENT);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("Vanilla");
        options.add("Float");
        options.add("HyCraft");
        options.add("fast");
        options.add("ACFly1");
        options.add("ACFly2");
        options.add("ACFly3");
        
        Andos.instance.settingsManager.rSetting(new Setting("Flight Mode", this, "Vanilla", options));
	}

	public void onEnable() {
		if(Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("HyCraft")) {
			mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 6, mc.thePlayer.posZ);
			damaged = true;
		}
		if(this.isToggled() && Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly2")) {
			startY = player().posY;
		}
	}
	
	public void onDisable() {
		damaged = false;
		mc.timer.timerSpeed = 1.0f;
		mc.thePlayer.capabilities.isFlying = false;
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if(Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("Vanilla")) {
				mc.thePlayer.capabilities.isFlying = true;
			}
			if(Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("Float")) {
				mc.thePlayer.motionY = 0;
			}
			if(Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("HyCraft")) {
				if(damaged && mc.gameSettings.keyBindForward.pressed) {
					if(timer.hasReached(50L)) {
						mc.timer.timerSpeed = 0.26f;
						timer.reset();
					}else {
						mc.timer.timerSpeed = 0.28f;
					}
					
					this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 0.05, this.mc.thePlayer.posZ);
					
					double oldY = mc.thePlayer.motionY;
					float oldJ = mc.thePlayer.jumpMovementFactor;
					if(this.isToggled()) {
						if((mc.thePlayer.motionY < 0.0d) && (mc.thePlayer.isAirBorne) && (!mc.thePlayer.isInWater()) && (!mc.thePlayer.isOnLadder())) {
							if(!mc.thePlayer.isInsideOfMaterial(Material.lava)) {
								mc.thePlayer.motionY = -.125d;
								mc.thePlayer.jumpMovementFactor *= 1.12337f;
							}
						}
					}else {
						mc.thePlayer.motionY = oldY;
						mc.thePlayer.jumpMovementFactor = oldJ;
					}
					
					mc.thePlayer.setSprinting(false);
					mc.thePlayer.onGround = true;
					mc.thePlayer.fallDistance = -1;
					mc.thePlayer.isInWeb = false;
					mc.thePlayer.capabilities.isFlying = true;
					mc.thePlayer.capabilities.setFlySpeed(0.01f);
					
					int state = 0;
					double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
					double x = -Math.sin(yaw) * 1;
					double z = Math.cos(yaw) * 1;
					if(state == 0) {
						mc.thePlayer.setPosition(mc.thePlayer.posX + x, mc.thePlayer.posY + 0.25, mc.thePlayer.posZ + z);
						mc.thePlayer.motionX *= 1.0;
						mc.thePlayer.motionX *= 1.0;
						state = 1;
					}
					if(state == 1) {
						mc.thePlayer.setPosition(mc.thePlayer.posX + x, mc.thePlayer.posY - 0.125, mc.thePlayer.posZ + z);
						mc.thePlayer.motionX *= 0.7;
						mc.thePlayer.motionX *= 0.7;
						state = 0;
					
				}
				}
			}
			
			if(this.isToggled() && Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("fast")) {
				mc.timer.timerSpeed = 11f;
				float speed = (float) 8.44;
				mc.thePlayer.capabilities.isFlying = false;
				mc.thePlayer.isInWeb = false;
				mc.thePlayer.motionY = 0;
				mc.thePlayer.motionX = 0;
				mc.thePlayer.motionZ = 0;
				mc.thePlayer.jumpMovementFactor = speed;
				
				if (mc.gameSettings.keyBindJump.getIsKeyPressed())
				{
					mc.thePlayer.motionY = speed;
				}
				
				if (mc.gameSettings.keyBindSneak.getIsKeyPressed())
				{
					mc.thePlayer.motionY = 0 - speed;
				}
			}
			if(this.isToggled() && Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly1") ) {
				if (player().isSneaking())
					player().motionY = -0.4;
				else if (mc.gameSettings.keyBindJump.isPressed())
					player().motionY = 0.4;
				else
					player().motionY = 0;
				player().motionX *= 1.1;
				player().motionZ *= 1.1;
			}
				
			
			if(this.isToggled() && Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly2")) {
				for(int i = 0; i < 5; i++) {
					mc.thePlayer.motionY /= 1.010;
				}
				if (startY > player().posY)
					player().motionY = 0.5;
			}
			
			if(this.isToggled() && Andos.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly3")) {
				if(mc.thePlayer.onGround == true) mc.thePlayer.jump();
				else {
					int state = 0;
					mc.timer.timerSpeed = 0.70f;
					mc.thePlayer.motionY = 0;
					if(mc.gameSettings.keyBindJump.pressed == true) {
						mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.050, mc.thePlayer.posZ);
					}
					if(mc.gameSettings.keyBindSneak.pressed == true) {
						mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.050, mc.thePlayer.posZ);
					}
					
					if(state == 0) {
						mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.050, mc.thePlayer.posZ);
						state = 1;
					}
					if(state == 1) {
						mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.053, mc.thePlayer.posZ);
						state = 0;
					}
				}
			}
		}
	}

}
