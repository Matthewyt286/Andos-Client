package Andos.Module.movement;

import Andos.Module.Category;
import Andos.Module.Module;
import net.minecraft.util.AxisAlignedBB;

public class AntiVoid extends Module{

	public AntiVoid() {
		super("AntiVoid", 0, Category.MOVEMENT);
	}
	
	@Override
    public void onUpdate() {
		if(!this.isToggled()) return;
            if (mc.thePlayer.fallDistance > 10 && !mc.thePlayer.onGround) {
                if (!isBlockUnder()) {
                	mc.thePlayer.motionY = 0;
                
            }
        }
    }
	
	private boolean isBlockUnder() {
        if (mc.thePlayer.posY < 0)
            return false;
        for (int offset = 0; offset < (int) mc.thePlayer.posY + 2; offset += 2) {
            AxisAlignedBB bb = mc.thePlayer.getEntityBoundingBox().offset(0, -offset, 0);
            if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, bb).isEmpty()) {
                return true;
            }
        }
        return false;
    }

}
