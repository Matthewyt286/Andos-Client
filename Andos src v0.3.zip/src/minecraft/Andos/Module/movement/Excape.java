package Andos.Module.movement;

import org.lwjgl.input.Keyboard;

import Andos.Module.Category;
import Andos.Module.Module;

public class Excape extends Module{
	
	public double X;
	public double Y;
	public double Z;
	
	public Excape() {
		super("Clip", Keyboard.KEY_N, Category.MOVEMENT);
	}
	
	public void onEnable() {
		X = mc.thePlayer.posX;
		Y = mc.thePlayer.posY;
		Z = mc.thePlayer.posZ;
		mc.thePlayer.setPosition(X, Y + 5, Z);
		toggle();
	}

}
