package Andos.Module.movement;

import org.lwjgl.input.Keyboard;

import Andos.Module.Module;
import Andos.Module.Category;

import net.minecraft.network.play.client.C03PacketPlayer;

public class NoFall extends Module{
	
	public NoFall() {
		super("NoFall", 0, Category.MOVEMENT);
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			if(mc.thePlayer.fallDistance > 2f) {
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
			}
			super.onUpdate();
		}
	}

}
