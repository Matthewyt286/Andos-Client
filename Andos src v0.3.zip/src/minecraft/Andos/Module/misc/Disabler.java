package Andos.Module.misc;

import java.util.ArrayList;

import Andos.Andos;
import Andos.Module.Category;
import Andos.Module.Module;
import de.Hero.settings.Setting;
import net.minecraft.network.status.client.C01PacketPing;

public class Disabler extends Module{

	public Disabler() {
		super("Disabler", 0, Category.MISC);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("Ping");
        
        Andos.instance.settingsManager.rSetting(new Setting("Disabler Mode", this, "Ping", options));
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			if(Andos.instance.settingsManager.getSettingByName("Disabler Mode").getValString().equalsIgnoreCase("Ping")) {
				C01PacketPing packet = new C01PacketPing();
				mc.thePlayer.sendQueue.addToSendQueue(packet);
			}
		}
	}

}
