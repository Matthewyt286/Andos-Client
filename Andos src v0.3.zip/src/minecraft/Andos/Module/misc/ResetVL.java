package Andos.Module.misc;

import org.lwjgl.input.Keyboard;

import Andos.Module.Category;
import Andos.Module.Module;

public class ResetVL extends Module{

	public ResetVL() {
		super("ResetVL", Keyboard.KEY_F12, Category.MISC);
	}
	
	public double motionX;
	public double motionY;
	public double motionZ;
	
	public double X;
	public double Y;
	public double Z;
	
	public void onEnable() {
		motionX = mc.thePlayer.motionX;
		motionY = mc.thePlayer.motionY;
		motionZ = mc.thePlayer.motionZ;
		
		X = mc.thePlayer.posX;
		Y = mc.thePlayer.posY;
		Z = mc.thePlayer.posZ;
		
		for(int i = 0; i < 5; i++) {
			mc.thePlayer.motionX = 0;
			mc.thePlayer.motionY = 0;
			mc.thePlayer.motionZ = 0;
			mc.thePlayer.posX = X - 0.1;
			mc.thePlayer.posY = Y - 0.1;
			mc.thePlayer.posZ = Z - 0.1;
			mc.thePlayer.motionX = motionX;
			mc.thePlayer.motionY = motionY;
			mc.thePlayer.motionZ = motionZ;
			mc.thePlayer.posX = X;
			mc.thePlayer.posY = Y;
			mc.thePlayer.posZ = Z;
		}
		toggle();
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
				
		}
	}

}
