package Andos.Module;

import java.util.ArrayList;
import java.util.List;

import Andos.Andos;
import Andos.Module.client.*;
import Andos.Module.movement.*;
import Andos.Module.render.*;
import Andos.Module.combat.*;
import Andos.Module.player.*;
import Andos.Module.misc.*;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class ModuleManager {

	private static ArrayList<Module> mods;

	public ModuleManager() {
		mods = new ArrayList<Module>();
		newMod(new NoScoreboard());
		newMod(new Excape());
		newMod(new ClickGui());
		newMod(new KillAura2());
		newMod(new Flight());
		newMod(new AutoSprint());
		newMod(new InvMove());
		newMod(new NoFall());
		newMod(new Sneak());
		newMod(new Jetpack());
		newMod(new LongJump());
		newMod(new Speed());
		newMod(new Scaffold());
		newMod(new Animations());
		newMod(new Velocity());
		newMod(new ChestStealer());
		newMod(new AutoClicker());
		newMod(new HudMod());
		newMod(new FullBright());
		newMod(new PlayerESP());
		newMod(new ChestESP());
		newMod(new InventoryManager());
		newMod(new FastPlace());
		newMod(new Eagle());
		newMod(new ResetVL());
		newMod(new AntiVoid());
//		newMod(new ShaderESP());
		
	}

	public static List<Module> getModulesbyCategory(Category c) {
		List<Module> modules = new ArrayList<Module>();

		for (Module m : Andos.instance.moduleManager.getModules()) {
			if (m.category == c)
				modules.add(m);
		}
		return modules;
	}

	public static void newMod(Module m) {
		mods.add(m);
	}

	public static ArrayList<Module> getModules() {
		return mods;
	}

	public static void onUpdate() {
		for (Module m : mods) {
			m.onUpdate();
		}
	}

	public static void onRender() {
		for (Module m : mods) {
			m.onRender();
		}
	}

	public static void onKey(int k) {
		for (Module m : mods) {
			if (m.getKey() == k) {
				m.toggle();
			}
		}
	}
	
	public static void addChatMessage(String message) {
		message = "\u00A75" + "Andos Client" + "\2477: " + message;
		
		Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(message));
	}

}
