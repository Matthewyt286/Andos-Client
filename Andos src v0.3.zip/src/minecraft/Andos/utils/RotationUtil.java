package Andos.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public final class RotationUtil {

    private static float prevYaw, prevPitch;
    private static long prevTime;

    public static float[] getRotations(EntityLivingBase target) {
        float sensitivity = 0;
        float yaw, pitch;
        Vec3 targetPos = new Vec3(target.posX, target.posY, target.posZ);
        Vec3 playerPos = new Vec3(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);

        double var1 = targetPos.xCoord - playerPos.xCoord;
        double var3 = targetPos.yCoord - playerPos.yCoord;
        double var5 = targetPos.zCoord - playerPos.zCoord;
        double var7 = (double) MathHelper.sqrt_double(var1 * var1 + var5 * var5);
        float var9 = (float) (Math.atan2(var5, var1) * 180.0D / Math.PI) - 90.0F;
        float var10 = (float) (-(Math.atan2(var3, var7) * 180.0D / Math.PI));

        float deltaPitch = var10 - prevPitch;
        float deltaYaw = var9 - prevYaw;
        long deltaTime = System.currentTimeMillis() - prevTime;
        float deltaRotation = (float) (Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch));
        float smoothness = Math.min(1.0f, (float) deltaTime / sensitivity);
        float smoothing = smoothness * deltaRotation;

        yaw = prevYaw + deltaYaw * smoothing;
        pitch = prevPitch + deltaPitch * smoothing;

        prevYaw = yaw;
        prevPitch = pitch;
        prevTime = System.currentTimeMillis();

        return new float[]{yaw, pitch};

    }
 

}