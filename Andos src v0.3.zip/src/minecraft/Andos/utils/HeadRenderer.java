package Andos.utils;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;

public class HeadRenderer{

	  //draw head
	    public static void drawPlayerHead(int x, int y, int width, EntityLivingBase player) {//width and height are the same number so yeah yes aha
	    	NetworkPlayerInfo playerInfo = Minecraft.getMinecraft().getNetHandler().func_175102_a(player.getUniqueID());
	    	if (playerInfo != null){
	            Minecraft.getMinecraft().getTextureManager().bindTexture(playerInfo.func_178837_g());
	            GL11.glColor4f(1F, 1F, 1F, 1F);

	            Gui.drawScaledCustomSizeModalRect((int) x - 5, (int) y - 5, 8F, 8F, 8, 8, 20, 20, 64F, 64F);
	        }
	        
	    }
	    
	    public void drawPlayerHead(int x, int y, int width) {//width and height are the same number so yeah yes aha
	    	if(Minecraft.getMinecraft().thePlayer != null) {
		    	GlStateManager.pushMatrix();
		        float scale = width / 32;
		        GlStateManager.scale(scale, scale, scale);
		        Minecraft.getMinecraft().getTextureManager().bindTexture(Minecraft.getMinecraft().thePlayer.getLocationSkin());
		        GL11.glEnable(GL11.GL_BLEND);
		        GL11.glDisable(GL11.GL_BLEND);
		        GlStateManager.popMatrix();
	    	}
	    }
	  
	}