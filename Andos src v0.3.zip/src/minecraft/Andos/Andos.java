package Andos;

import org.lwjgl.opengl.Display;

import Alt.AltManager;
import Andos.Module.ModuleManager;
import de.Hero.clickgui.ClickGUI;
import de.Hero.settings.SettingsManager;

public class Andos {
	
	public static double ver = 0.3;
//	public static String ver = "bro my client run away";
	
	public static Andos instance = new Andos();
	public static SettingsManager settingsManager;
	public static ModuleManager moduleManager;
	public static ClickGUI clickGUI;
	public static AltManager altManager;
	
	public static void startClient() {
		Display.setResizable(true);
		Display.setTitle("Minecraft 1.8");
		settingsManager = new SettingsManager();
		moduleManager = new ModuleManager();
		clickGUI = new ClickGUI();
		altManager = new AltManager();
	}

}
